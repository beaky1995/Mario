﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class FireballUtil
    {
        public static float velocityY = 2.0f;
        public static float velocityX = 3.5f;
        public static int bouceOriginY = 0;
        public static int maxY = 20;
    }
}
