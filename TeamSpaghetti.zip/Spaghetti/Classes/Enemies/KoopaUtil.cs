﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class KoopaUtil
    {
        public static float yMotion = 2f;
        public static int score = 100;
        public static int gravity = 2;
        public static int startMoving = 400;
    }
}