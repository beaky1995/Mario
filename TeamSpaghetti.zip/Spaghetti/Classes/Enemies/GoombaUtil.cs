﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class GoombaUtil
    {
        public static float xSpeed = .5f;
        public static int score = 100;
        public static float gravity = 2.3f;
        public static int startMoving = 400;
    }
}
