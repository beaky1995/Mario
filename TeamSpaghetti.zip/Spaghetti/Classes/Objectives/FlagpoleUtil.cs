﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class FlagpoleUtil
    {
        public static int flagSpeedX = 13;
        public static int flagSpeedY = 8;
        public static int flagMaxY = 172;
    }
}
