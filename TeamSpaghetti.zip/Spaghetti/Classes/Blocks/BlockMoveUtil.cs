﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class BlockMoveUtil
    {
        public static int maxY = 5;
        public static int speedY = 1;
        public static int blockDefault = 0;
        public static int blockItems = 1;
        public static float toadYAdjust = 8f;
    }
}
