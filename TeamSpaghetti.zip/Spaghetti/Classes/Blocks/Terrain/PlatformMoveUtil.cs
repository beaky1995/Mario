﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class PlatformMoveUtil
    {
        public static int maxX = 30;
        public static float xVelocity = 1.0f;
    }
}
