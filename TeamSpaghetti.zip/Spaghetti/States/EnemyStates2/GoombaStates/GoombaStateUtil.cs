﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{ 
    public class GoombaStateUtil
    {
        public static int flippedTimer = 100;
        public static float speedX = 0.5f;
        public static int runningStompedTimer = 8;
    }
}
