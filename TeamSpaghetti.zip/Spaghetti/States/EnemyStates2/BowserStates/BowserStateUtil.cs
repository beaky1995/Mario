﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{ 
    public class BowserStateUtil
    {
        public static float speedX = 0.2f;
        public static float velocityY = 6f;
        public static float velocityReductionFactor = 0.9f;
        public static float velocityThreshold = 1f;
    }
}
