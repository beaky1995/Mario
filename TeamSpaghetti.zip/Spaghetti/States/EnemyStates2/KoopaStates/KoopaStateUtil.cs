﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class KoopaStateUtil
    {
        public static int flippedTimer = 100;
        public static float speedX = 0.5f;
        public static int lethalTimer = 2;
        public static int flippedSpeedX = 3;
        public static string movingLeft = "left";
        public static string movingRight = "right";


    }
}
