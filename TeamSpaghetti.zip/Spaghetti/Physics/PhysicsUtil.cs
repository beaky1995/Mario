﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class PhysicsUtil
    {

        public static float maxXVelocity = 3.5f;
       
        public static float minYVelocity = 3.8f;
        public static float MaxYVelocity = 6.0f;

        public static float sprintVelocityMultiplier = 1.05f;


        public static float firstPhaseXVelocity = 1.5f;
        public static float firstPhaseMultiplier = 0.04f;
        public static float secondPhaseMultiplier = 0.05f;
        
    }
}
