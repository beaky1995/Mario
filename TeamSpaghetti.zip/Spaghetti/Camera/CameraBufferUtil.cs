﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class CameraUtil
    {
        public static float bufferTop = 0.2f;
        public static float bufferBottom = 0.8f;
        public static float bufferRight = 0.4f;

        public static int windowMaxX = 360;
        public static int windowMinX = 0;
        public static int windowMaxY = 240;
        public static int windowMinY = 0;
    }
}
