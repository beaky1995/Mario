﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    public class ControllerUtil
    {
        public static int jumpDelay = 0;
        public static int jumpMaxDelay = 14;

        public static int fireballDelay = 0;

        public static float gamePadThreshold = -0.5f;

        public static int mouseInitX = 0;
        public static int mouseInitY = 0;
    }
}
