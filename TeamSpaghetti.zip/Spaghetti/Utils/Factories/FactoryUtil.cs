﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti { 
    public class FactoryUtil
    {
        public static int Spritebase = 1;
        public static int twoSeparatedSprite = 2;
        public static int threeSeparatedSprite = 3;
        public static int fourSeparatedSprite = 4;
    }
}
