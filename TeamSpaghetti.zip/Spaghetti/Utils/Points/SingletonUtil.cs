﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
    class SingletonUtil
    {
        public static int scoreInit = 0;
        public static int timerDelay = 100;
        public static int bounceInit = 0;
        public static int stompInit = 0;
    }
}
