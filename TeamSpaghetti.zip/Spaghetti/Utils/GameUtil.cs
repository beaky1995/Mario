﻿using System.IO;

namespace Spaghetti
{
    public class GameUtil
    {
        public static int delayIntro = 100;
        public static int delayResetOnDeath = 200;
        public static int fileLocationOffset = 22;
        public static string levelSubPath = "\\Content\\Levels\\Level1-1.xml";
        public static string sprint6LevelSubPath = "\\Content\\Levels\\Level1-4.xml";
        public static string StartMenuLevelSubPath = "\\Content\\Levels\\StartMenu.xml";
    }
}
