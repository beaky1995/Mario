﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaghetti
{
   public class coinCounterUtil
    {
        public static int baseCount = 0;
        public static int liveCounter = 3;
    }
}
