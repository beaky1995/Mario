﻿namespace Spaghetti
{

    public interface ICommand
    {
        void Execute();

    }
}
