﻿using Microsoft.Xna.Framework.Graphics;

namespace Spaghetti
{
    public interface IBackground: IDrawable, IUpdatable
    {

    }
}
