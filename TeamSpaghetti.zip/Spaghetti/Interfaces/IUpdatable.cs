﻿namespace Spaghetti
{
    public interface IUpdatable
    {
        void Update();
    }
}
