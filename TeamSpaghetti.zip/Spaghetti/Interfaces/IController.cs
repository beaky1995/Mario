﻿namespace Spaghetti 
{

    public interface IController: IUpdatable
    {
        //void RegisterCommand(Keys key, ICommand command);
    }
}